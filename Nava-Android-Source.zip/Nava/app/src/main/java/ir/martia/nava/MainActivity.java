package ir.martia.nava;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.text.*;
import android.view.*;
import android.widget.*;
import androidx.media3.common.*;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 private final int BG=0xff101019, PANEL=0xff201e30, ACCENT=0xffb59aff, MUTED=0xffa7a2bb;
 private final ArrayList<MediaItem> songs=new ArrayList<>(), visible=new ArrayList<>();
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 private final Handler handler=new Handler(Looper.getMainLooper());
 private MediaController player;
 private ListenableFuture<MediaController> connection;
 private LinearLayout root;
 private TextView title,artist,count,time,empty;
 private Button play,heart,shuffle,repeat;
 private SeekBar seek;
 private EditText search;
 private ListView list;
 private BaseAdapter adapter;
 private RecordView record;
 private boolean favoritesOnly=false, scanning=false, started=false;
 private Set<String> favorites;
 private final Runnable ticker=new Runnable(){public void run(){ update(); if(started) handler.postDelayed(this,500); }};

 @Override public void onCreate(Bundle state){
  super.onCreate(state);
  favorites=new HashSet<>(getPreferences(0).getStringSet("favorites",Collections.emptySet()));
  buildUI();
 }
 @Override public void onStart(){
  super.onStart(); started=true;
  connection=new MediaController.Builder(this,new SessionToken(this,new ComponentName(this,PlaybackService.class))).buildAsync();
  connection.addListener(()->{
   if(!started)return;
   try { player=connection.get(); player.addListener(new Player.Listener(){
    @Override public void onEvents(Player p, Player.Events events){update();}
    @Override public void onPlayerError(PlaybackException error){Toast.makeText(MainActivity.this,"این فایل قابل پخش نیست؛ آهنگ دیگری انتخاب کنید",Toast.LENGTH_LONG).show();}
   });update(); }catch(Exception ex){empty.setText("اتصال به پخش‌کننده انجام نشد؛ برنامه را دوباره باز کنید");}
  },command -> handler.post(command));
  handler.post(ticker);
  if(hasAccess())scan();
 }
 @Override public void onStop(){started=false;handler.removeCallbacks(ticker);player=null;if(connection!=null)MediaController.releaseFuture(connection);super.onStop();}
 @Override public void onDestroy(){worker.shutdownNow();super.onDestroy();}
 private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
 private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 private TextView label(String text,int size,int color){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.CENTER);return v;}
 private Button button(String text,String description,Runnable action){Button b=new Button(this);b.setText(text);b.setTextColor(ACCENT);b.setTextSize(14);b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(5),0,dp(5),0);b.setBackground(shape(PANEL,18));b.setContentDescription(description);b.setOnClickListener(v->action.run());return b;}
 private void add(LinearLayout box,View child,int height){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(height));lp.bottomMargin=dp(8);box.addView(child,lp);}
 private void slot(LinearLayout box,View v){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(50),1);lp.setMargins(dp(3),0,dp(3),0);box.addView(v,lp);}
 private void buildUI(){
  root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setPadding(dp(18),dp(8),dp(18),0);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
  root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=Build.VERSION.SDK_INT>=30?insets.getInsets(WindowInsets.Type.systemBars()):null;
   int top=bars!=null?bars.top:insets.getSystemWindowInsetTop(),bottom=bars!=null?bars.bottom:insets.getSystemWindowInsetBottom();
   root.setPadding(dp(18),top+dp(8),dp(18),bottom);return insets;});
  setContentView(root);
  LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
  TextView brand=label("مارتیا / MARTIA",28,0xfff6f2ff);brand.setGravity(Gravity.RIGHT);header.addView(brand,new LinearLayout.LayoutParams(0,dp(52),1));
  header.addView(button("↻","بازخوانی آهنگ‌ها",()->{if(hasAccess())scan();else requestAccess();}),new LinearLayout.LayoutParams(dp(52),dp(48)));add(root,header,56);
  search=new EditText(this);search.setSingleLine(true);search.setTextColor(0xfff6f2ff);search.setHintTextColor(MUTED);search.setTextSize(15);search.setHint("جست‌وجوی آهنگ یا خواننده…");search.setPadding(dp(16),0,dp(16),0);search.setBackground(shape(PANEL,18));add(root,search,48);
  search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int c){filter();}public void afterTextChanged(Editable e){}});
  LinearLayout tabs=new LinearLayout(this);
  slot(tabs,button("همه آهنگ‌ها","همه آهنگ‌ها",()->{favoritesOnly=false;filter();}));
  slot(tabs,button("♥ علاقه‌مندی‌ها","نمایش علاقه‌مندی‌ها",()->{favoritesOnly=true;filter();}));add(root,tabs,50);
  count=label("موسیقی تو، دنیای تو",13,MUTED);add(root,count,25);
  FrameLayout library=new FrameLayout(this);root.addView(library,new LinearLayout.LayoutParams(-1,0,1));
  list=new ListView(this);list.setDividerHeight(dp(5));list.setDivider(null);library.addView(list,new FrameLayout.LayoutParams(-1,-1));
  empty=label("برای دیدن آهنگ‌ها، دسترسی موسیقی را فعال کن\nبرای ادامه لمس کن",15,MUTED);empty.setPadding(dp(12),dp(12),dp(12),dp(12));library.addView(empty,new FrameLayout.LayoutParams(-1,-1));list.setEmptyView(empty);empty.setOnClickListener(v->{if(hasAccess())scan();else requestAccess();});
  adapter=new BaseAdapter(){public int getCount(){return visible.size();}public Object getItem(int p){return visible.get(p);}public long getItemId(int p){return p;}
   public View getView(int position,View recycled,android.view.ViewGroup parent){MediaItem item=visible.get(position);LinearLayout row=new LinearLayout(MainActivity.this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(8),dp(12),dp(8));row.setBackground(shape(PANEL,16));
    TextView icon=label(favorites.contains(item.mediaId)?"♥":"♫",24,ACCENT);row.addView(icon,new LinearLayout.LayoutParams(dp(44),dp(50)));
    LinearLayout names=new LinearLayout(MainActivity.this);names.setOrientation(1);TextView name=label(String.valueOf(item.mediaMetadata.title),16,0xfff6f2ff);name.setGravity(Gravity.RIGHT);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);names.addView(name);
    TextView by=label(String.valueOf(item.mediaMetadata.artist),12,MUTED);by.setGravity(Gravity.RIGHT);by.setSingleLine(true);by.setEllipsize(TextUtils.TruncateAt.END);names.addView(by);row.addView(names,new LinearLayout.LayoutParams(0,-2,1));return row;}
  };list.setAdapter(adapter);list.setOnItemClickListener((p,v,pos,id)->{if(player==null){Toast.makeText(this,"پخش‌کننده در حال آماده‌شدن است",0).show();return;}player.setMediaItems(new ArrayList<>(visible),pos,0);player.prepare();player.play();});
  LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(12),dp(12),dp(8));card.setBackground(shape(0xff28213e,24));
  LinearLayout info=new LinearLayout(this);info.setGravity(Gravity.CENTER_VERTICAL);record=new RecordView();info.addView(record,new LinearLayout.LayoutParams(dp(62),dp(62)));
  LinearLayout names=new LinearLayout(this);names.setOrientation(1);title=label("یک آهنگ انتخاب کن",17,0xfff6f2ff);title.setSingleLine(true);title.setEllipsize(TextUtils.TruncateAt.END);artist=label("همیشه همراه تو",12,MUTED);artist.setSingleLine(true);names.addView(title);names.addView(artist);info.addView(names,new LinearLayout.LayoutParams(0,-2,1));heart=button("♡","افزودن یا حذف علاقه‌مندی",this::favorite);info.addView(heart,new LinearLayout.LayoutParams(dp(48),dp(48)));card.addView(info);
  seek=new SeekBar(this);seek.setMax(1000);seek.setProgressTintList(ColorStateList.valueOf(ACCENT));seek.setThumbTintList(ColorStateList.valueOf(ACCENT));seek.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);card.addView(seek,new LinearLayout.LayoutParams(-1,dp(28)));
  seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int value,boolean user){if(user&&player!=null&&player.getDuration()>0)player.seekTo(player.getDuration()*value/1000);}});
  time=label("0:00  /  0:00",11,MUTED);card.addView(time);
  LinearLayout controls=new LinearLayout(this);controls.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
  shuffle=button("⇄","پخش تصادفی",()->{if(player!=null)player.setShuffleModeEnabled(!player.getShuffleModeEnabled());});slot(controls,shuffle);
  slot(controls,button("❮❮","آهنگ قبلی",()->{if(player!=null)player.seekToPreviousMediaItem();}));
  play=button("▶","پخش یا مکث",()->{if(player==null)return;if(player.isPlaying())player.pause();else {if(player.getPlaybackState()==Player.STATE_ENDED)player.seekToDefaultPosition();if(player.getPlaybackState()==Player.STATE_IDLE)player.prepare();player.play();}});play.setBackground(shape(ACCENT,18));play.setTextColor(BG);slot(controls,play);
  slot(controls,button("❯❯","آهنگ بعدی",()->{if(player!=null)player.seekToNextMediaItem();}));
  repeat=button("↻","تکرار خاموش، همه یا یک آهنگ",()->{if(player!=null){int mode=player.getRepeatMode();player.setRepeatMode(mode==Player.REPEAT_MODE_OFF?Player.REPEAT_MODE_ALL:mode==Player.REPEAT_MODE_ALL?Player.REPEAT_MODE_ONE:Player.REPEAT_MODE_OFF);}});slot(controls,repeat);card.addView(controls);root.addView(card,new LinearLayout.LayoutParams(-1,-2));
 }
 private String permission(){return Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;}
 private boolean hasAccess(){return checkSelfPermission(permission())==PackageManager.PERMISSION_GRANTED;}
 private void requestAccess(){if(!hasAccess()&&!shouldShowRequestPermissionRationale(permission())&&getPreferences(0).getBoolean("asked",false)){
  new android.app.AlertDialog.Builder(this).setMessage("برای نمایش آهنگ‌های گوشی، دسترسی موسیقی را در تنظیمات مارتیا فعال کن.").setPositiveButton("تنظیمات",(d,w)->startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())))).setNegativeButton("بعداً",null).show();
 }else {getPreferences(0).edit().putBoolean("asked",true).apply();requestPermissions(new String[]{permission()},7);}}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] results){super.onRequestPermissionsResult(r,p,results);if(r==7){if(hasAccess())scan();else empty.setText("دسترسی داده نشد؛ برای تلاش دوباره لمس کن");}}
 private void scan(){if(scanning)return;scanning=true;count.setText("در حال پیدا کردن آهنگ‌ها…");worker.execute(()->{
  ArrayList<MediaItem> found=new ArrayList<>();String problem=null;
  String[] cols={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST,MediaStore.Audio.Media.ALBUM_ID};
  try(Cursor c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,cols,MediaStore.Audio.Media.IS_MUSIC+" != 0",null,MediaStore.Audio.Media.TITLE+" COLLATE NOCASE ASC")){
   if(c!=null)while(c.moveToNext()){
    long id=c.getLong(0);String name=c.getString(1),by=c.getString(2);
    if(by==null||by.equals("<unknown>"))by="خواننده نامشخص";
    Uri audio=ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id);
    Uri art=ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"),c.getLong(3));
    found.add(new MediaItem.Builder().setMediaId(Long.toString(id)).setUri(audio).setMediaMetadata(new MediaMetadata.Builder().setTitle(name==null?"بدون نام":name).setArtist(by).setArtworkUri(art).build()).build());
   }
  }catch(Exception e){problem="خواندن آهنگ‌ها ممکن نشد؛ دسترسی موسیقی را بررسی کن";}
  final String error=problem;handler.post(()->{scanning=false;if(isDestroyed())return;songs.clear();songs.addAll(found);filter();if(error!=null)empty.setText(error);});
 });}
 private String normalize(String s){return s.toLowerCase(Locale.ROOT).replace('ي','ی').replace('ك','ک');}
 private void filter(){if(adapter==null)return;String q=normalize(search.getText().toString().trim());visible.clear();for(MediaItem s:songs)if((!favoritesOnly||favorites.contains(s.mediaId))&&normalize(s.mediaMetadata.title+" "+s.mediaMetadata.artist).contains(q))visible.add(s);
  count.setText((favoritesOnly?"علاقه‌مندی‌ها · ":"روی گوشی · ")+visible.size()+" آهنگ");empty.setText(!hasAccess()?"برای دسترسی به موسیقی، اینجا لمس کن":favoritesOnly?"هنوز آهنگی در علاقه‌مندی‌ها نیست":q.isEmpty()?"آهنگی پیدا نشد؛ فایل موسیقی را روی گوشی ذخیره و بازخوانی کن":"نتیجه‌ای پیدا نشد");adapter.notifyDataSetChanged();}
 private void favorite(){if(player==null||player.getCurrentMediaItem()==null)return;String id=player.getCurrentMediaItem().mediaId;if(!favorites.add(id))favorites.remove(id);getPreferences(0).edit().putStringSet("favorites",new HashSet<>(favorites)).apply();filter();update();}
 private String clock(long ms){long sec=Math.max(0,ms)/1000;return String.format(Locale.US,"%d:%02d",sec/60,sec%60);}
 private void update(){if(player==null)return;MediaItem item=player.getCurrentMediaItem();if(item!=null){title.setText(item.mediaMetadata.title);artist.setText(item.mediaMetadata.artist);heart.setText(favorites.contains(item.mediaId)?"♥":"♡");}play.setText(player.isPlaying()?"Ⅱ":"▶");play.setContentDescription(player.isPlaying()?"مکث":"پخش");long duration=player.getDuration(),pos=player.getCurrentPosition();seek.setEnabled(duration>0);seek.setProgress(duration>0?(int)(pos*1000/duration):0);time.setText(clock(pos)+" / "+clock(duration));shuffle.setTextColor(player.getShuffleModeEnabled()?0xff77edce:MUTED);repeat.setText(player.getRepeatMode()==Player.REPEAT_MODE_ONE?"↻ ۱":"↻");repeat.setTextColor(player.getRepeatMode()!=Player.REPEAT_MODE_OFF?0xff77edce:MUTED);record.active=player.isPlaying();record.invalidate();}
 private class RecordView extends View {
  Paint p=new Paint(3);boolean active;
  RecordView(){super(MainActivity.this);setContentDescription("صفحه موسیقی مارتیا");}
  @Override protected void onDraw(Canvas c){super.onDraw(c);float x=getWidth()/2f,y=getHeight()/2f,r=Math.min(x,y)-dp(4);p.setShader(new LinearGradient(0,0,getWidth(),getHeight(),0xffb59aff,0xff534398,Shader.TileMode.CLAMP));c.drawCircle(x,y,r,p);p.setShader(null);p.setColor(0xff211b35);c.drawCircle(x,y,r*.76f,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(0xff594774);for(float a=.38f;a<.75f;a+=.13f)c.drawCircle(x,y,r*a,p);p.setStyle(Paint.Style.FILL);p.setColor(active?0xff77edce:ACCENT);c.drawCircle(x,y,r*.18f,p);}
 }
}
